#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from std_msgs.msg import Int32

class ShapeNode(Node):
    
    def __init__(self):
        super().__init__('shape_node')
        self.publisher_ = self.create_publisher(Int32, 'shape_command', 10)
        self.get_logger().info(
            "Choose a command...\n"
            "1: Butterfly\n"
            "2: Flower\n"
            "3: Heart\n"
            "4: Stop turtle\n"
            "5: Clear screen\n"
        )
        self.timer = self.create_timer(1.0, self.get_user_input)

    def get_user_input(self):
        try:
            user_input = int(input("Enter a number: "))
            msg = Int32()
            msg.data = user_input
            self.publisher_.publish(msg)
        except ValueError:
            self.get_logger().error("Invalid input!")

def main(args=None):
    rclpy.init(args=args)
    node = ShapeNode()
    rclpy.spin(node)
    rclpy.shutdown()

if __name__ == '__main__':
    main()
