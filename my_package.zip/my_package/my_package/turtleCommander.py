import rclpy
from rclpy.node import Node
from std_msgs.msg import Int32
from turtlesim.srv import TeleportAbsolute
from std_srvs.srv import Empty
import math

class TurtleCommander(Node):
    def __init__(self):
        super().__init__('turtle_commander')

        # Subscriber to shape commands
        self.subscription = self.create_subscription(Int32, 'shape_command', self.shape_callback, 10)
        self.get_logger().info("Waiting for commands...")

        # Timer variables
        self.timer = None
        self.current_step = 0
        self.rate = 0.05   # seconds per step

        # Shape control
        self.shape_number = None
        self.stop_flag = False

        # Create service clients
        self.teleport_client = self.create_client(TeleportAbsolute, '/turtle1/teleport_absolute')
        while not self.teleport_client.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('Waiting for /turtle1/teleport_absolute service...')

        self.clear_client = self.create_client(Empty, '/clear')
        while not self.clear_client.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('Waiting for /clear service...')

    def shape_callback(self, msg):
        cmd = msg.data

        if cmd == 4:  # Stop turtle
            self.get_logger().info("Stopping turtle.")
            self.stop_flag = True

        elif cmd == 5:  # Clear screen
            self.get_logger().info("Clearing screen.")
            self.clear_screen()

        else:  # Draw a new shape
            self.shape_number = cmd
            self.stop_flag = False
            self.current_step = 0
            if self.timer is None:
                self.timer = self.create_timer(self.rate, self.draw_step)

    def clear_screen(self):
        self.move_turtle_to(5.5,5.5)
        req = Empty.Request()
        self.clear_client.call_async(req)


    def draw_step(self):
        if self.stop_flag:
            self.get_logger().info("Drawing stopped by user.")
            if self.timer is not None:
                self.timer.cancel()
                self.timer = None
            return

        # t goes from 0 to 2*pi continuously
        t = (self.current_step / 200) * 2 * math.pi  # 200 steps per cycle

        # Butterfly parametic equations
        if self.shape_number == 1:  
            x = math.sin(t) * (math.exp(math.cos(t)) - 2*math.cos(4*t) - math.sin(t/12)**5) + 5.5
            y = math.cos(t) * (math.exp(math.cos(t)) - 2*math.cos(4*t) - math.sin(t/12)**5) + 5.5

        # Flower parametic equations
        elif self.shape_number == 2:  
            r = 3.0*math.sin(5*t)
            x = r * math.cos(t) + 5.5
            y = r * math.sin(t) + 5.5

        # Heart parametric equations
        elif self.shape_number == 3:  
            x = (16*math.sin(t)**3)/4 + 5.5
            y = (13*math.cos(t) - 5*math.cos(2*t) - 2*math.cos(3*t) - math.cos(4*t))/4 + 5.5

        else:
            self.get_logger().warn("Invalid input!")
            self.stop_flag = True
            return

        self.move_turtle_to(x, y)
        self.current_step += 1

        # Loop steps indefinitely
        if self.current_step > 200:
            self.current_step = 0  # restart the shape

    def move_turtle_to(self, x, y):
        req = TeleportAbsolute.Request()
        req.x = x
        req.y = y
        req.theta = 0.0
        self.teleport_client.call_async(req)


def main(args=None):
    rclpy.init(args=args)
    node = TurtleCommander()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
