from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import ExecuteProcess

def generate_launch_description():
    ld = LaunchDescription()
    
    first_node = ExecuteProcess(
        cmd=['xterm', '-e', 'ros2 run my_package shapeNode'],
        output = 'screen',
        shell = True
    )

    second_node = Node(
        package='my_package',
        executable='turtleCommander',
        output = 'log'
    )

    ld.add_action(first_node)
    ld.add_action(second_node)

    return ld